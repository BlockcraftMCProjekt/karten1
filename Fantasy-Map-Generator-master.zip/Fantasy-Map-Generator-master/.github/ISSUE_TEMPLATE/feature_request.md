---
name: Feature request
about: Suggest an idea
title: ''
labels: pending review
assignees: Azgaar

---

<-- BEFORE CREATING PLEASE CHECK THE TO-DO LIST-->
<-- https://trello.com/b/7x832DG4/fantasy-map-generator ->>
**Problem**
<-- Is your feature request related to a problem? Please describe. Ex.: I'm always frustrated when ... -->

**Solution**
<-- A clear and concise description of what you want to happen and ideas on how it can be implemented. Screenshots are welcomed -->

**Alternatives**
<-- A clear and concise description of any alternative solutions or features you've considered -->
